# QtWuziqi
Qt 写的五子棋小游戏，带AI和双人对战
# ScreenShot
![](https://github.com/tashaxing/QtWuziqi/raw/master/pic/wuziqi.gif)<br/>
# BlogAddress
http://blog.csdn.net/u012234115/article/details/53871009
